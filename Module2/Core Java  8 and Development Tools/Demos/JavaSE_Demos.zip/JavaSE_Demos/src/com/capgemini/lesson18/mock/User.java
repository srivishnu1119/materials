package com.igate.lesson20.mock;

public class User {
String username, password;
}
